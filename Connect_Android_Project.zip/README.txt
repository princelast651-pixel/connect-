Connect Android project.
Website: https://princelast651-pixel.github.io/connect-/
Build using an Android Gradle environment and choose Build APK(s).
